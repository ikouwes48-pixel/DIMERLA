// ===========================
// DIMERLA Fashion Store - JS
// ===========================

// ===== DATA PRODUK =====
const products = [
  {
    id: 1,
    name: "Kemeja Batik Premium DIMERLA",
    description: "Kemeja batik eksklusif dengan motif khas Medan yang elegan. Cocok untuk acara formal dan semi-formal. Bahan katun premium yang nyaman dipakai sepanjang hari.",
    price: 485000,
    originalPrice: 620000,
    category: "baju",
    image: "https://images.unsplash.com/photo-1594938298603-c8148c4b4057?w=600&q=80",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Biru Navy", "Coklat", "Hijau"],
    isNew: false,
    isBestSeller: true,
    stock: 45
  },
  {
    id: 2,
    name: "Kaos Polo DIMERLA Classic",
    description: "Kaos polo casual berkualitas tinggi dengan bordir logo DIMERLA. Sempurna untuk aktivitas sehari-hari maupun hangout. Material pique cotton yang breathable.",
    price: 285000,
    originalPrice: 350000,
    category: "baju",
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&q=80",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Putih", "Hitam", "Merah", "Navy"],
    isNew: true,
    isBestSeller: false,
    stock: 60
  },
  {
    id: 3,
    name: "Jaket Bomber DIMERLA Urban",
    description: "Jaket bomber stylish dengan desain modern yang cocok untuk gaya urban. Bahan premium dengan lapisan dalam yang hangat. Tampil keren dan percaya diri.",
    price: 750000,
    originalPrice: 950000,
    category: "baju",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=80",
    sizes: ["M", "L", "XL", "XXL"],
    colors: ["Hitam", "Olive", "Navy"],
    isNew: true,
    isBestSeller: true,
    stock: 30
  },
  {
    id: 4,
    name: "Dress Casual Wanita DIMERLA",
    description: "Dress casual yang nyaman dan stylish untuk wanita modern. Desain yang flowy dan elegan, cocok untuk berbagai kesempatan dari casual hingga semi-formal.",
    price: 420000,
    originalPrice: 520000,
    category: "baju",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&q=80",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Merah Marun", "Biru Muda", "Krem"],
    isNew: true,
    isBestSeller: false,
    stock: 40
  },
  {
    id: 5,
    name: "Kemeja Polos Slim Fit",
    description: "Kemeja polos dengan potongan slim fit yang rapi dan modern. Cocok untuk ke kantor maupun acara casual. Tersedia dalam berbagai warna pilihan.",
    price: 320000,
    originalPrice: 400000,
    category: "baju",
    image: "https://images.unsplash.com/photo-1598032895397-b9472444bf93?w=600&q=80",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Putih", "Abu-abu", "Biru", "Hijau Sage"],
    isNew: false,
    isBestSeller: true,
    stock: 75
  },
  {
    id: 6,
    name: "Sneakers DIMERLA Street Runner",
    description: "Sneakers trendy dengan sol yang nyaman untuk aktivitas seharian. Desain modern yang cocok dipadukan dengan berbagai outfit. Material canvas premium yang tahan lama.",
    price: 580000,
    originalPrice: 720000,
    category: "sepatu",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80",
    sizes: ["38", "39", "40", "41", "42", "43", "44"],
    colors: ["Putih", "Hitam", "Abu-abu"],
    isNew: true,
    isBestSeller: true,
    stock: 55
  },
  {
    id: 7,
    name: "Sepatu Pantofel DIMERLA Executive",
    description: "Sepatu pantofel formal berkualitas tinggi untuk pria profesional. Kulit sintetis premium dengan jahitan rapi dan sol karet anti-slip. Kesan elegan dan berkelas.",
    price: 850000,
    originalPrice: 1100000,
    category: "sepatu",
    image: "https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=600&q=80",
    sizes: ["39", "40", "41", "42", "43", "44", "45"],
    colors: ["Hitam", "Coklat"],
    isNew: false,
    isBestSeller: true,
    stock: 35
  },
  {
    id: 8,
    name: "Sandal DIMERLA Comfort",
    description: "Sandal kasual yang nyaman dengan desain ergonomis. Sol empuk anti-lelah untuk menemani aktivitas santai. Material tahan air yang mudah dibersihkan.",
    price: 280000,
    originalPrice: 350000,
    category: "sepatu",
    image: "https://images.unsplash.com/photo-1603487742131-4160ec999306?w=600&q=80",
    sizes: ["37", "38", "39", "40", "41", "42"],
    colors: ["Coklat", "Hitam", "Putih"],
    isNew: false,
    isBestSeller: false,
    stock: 80
  },
  {
    id: 9,
    name: "Boots DIMERLA Highland",
    description: "Boots stylish dengan material kulit sintetis berkualitas tinggi. Cocok untuk tampilan casual maupun semi-formal. Dengan zipper samping untuk kemudahan pemakaian.",
    price: 920000,
    originalPrice: 1200000,
    category: "sepatu",
    image: "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=600&q=80",
    sizes: ["38", "39", "40", "41", "42", "43"],
    colors: ["Hitam", "Coklat Tua"],
    isNew: true,
    isBestSeller: false,
    stock: 25
  },
  {
    id: 10,
    name: "Topi Baseball DIMERLA",
    description: "Topi baseball dengan logo DIMERLA yang stylish. Material katun yang ringan dan breathable. Tali pengatur di bagian belakang untuk kenyamanan semua ukuran kepala.",
    price: 185000,
    originalPrice: 220000,
    category: "aksesoris",
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=600&q=80",
    sizes: ["Free Size"],
    colors: ["Hitam", "Putih", "Navy", "Merah"],
    isNew: false,
    isBestSeller: true,
    stock: 100
  },
  {
    id: 11,
    name: "Tas Selempang DIMERLA Crossbody",
    description: "Tas selempang unisex dengan desain modern dan fungsional. Bahan canvas premium dengan beberapa kompartemen yang memudahkan penyimpanan barang bawaan Anda.",
    price: 350000,
    originalPrice: 450000,
    category: "aksesoris",
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&q=80",
    sizes: ["Free Size"],
    colors: ["Hitam", "Olive", "Abu-abu"],
    isNew: true,
    isBestSeller: false,
    stock: 45
  },
  {
    id: 12,
    name: "Belt Kulit DIMERLA Classic",
    description: "Ikat pinggang kulit premium dengan buckle metalik elegan. Jahitan rapi dan kuat untuk ketahanan jangka panjang. Tersedia dalam berbagai ukuran.",
    price: 220000,
    originalPrice: 280000,
    category: "aksesoris",
    image: "https://images.unsplash.com/photo-1624222247344-550fb60583dc?w=600&q=80",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Hitam", "Coklat"],
    isNew: false,
    isBestSeller: false,
    stock: 60
  }
];

// ===== FORMAT RUPIAH =====
function formatRp(num) {
  return 'Rp ' + num.toLocaleString('id-ID');
}

// ===== DISCOUNT % =====
function discountPct(price, original) {
  if (!original) return 0;
  return Math.round((1 - price / original) * 100);
}

// ===== CART STATE (localStorage) =====
let cart = JSON.parse(localStorage.getItem('dimerla_cart') || '[]');

function saveCart() {
  localStorage.setItem('dimerla_cart', JSON.stringify(cart));
  updateCartUI();
}

function cartTotal() {
  return cart.reduce((sum, item) => sum + item.price * item.qty, 0);
}

function cartCount() {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

function addToCart(productId, size, color, qty) {
  const product = products.find(p => p.id === productId);
  if (!product) return;

  const key = `${productId}-${size}-${color}`;
  const existing = cart.find(i => i.key === key);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ key, id: productId, name: product.name, image: product.image, price: product.price, size, color, qty });
  }
  saveCart();
  showToast('✅ Produk ditambahkan ke keranjang!');
}

function removeFromCart(key) {
  cart = cart.filter(i => i.key !== key);
  saveCart();
}

function changeQty(key, delta) {
  const item = cart.find(i => i.key === key);
  if (!item) return;
  item.qty = Math.max(1, item.qty + delta);
  saveCart();
}

function clearCart() {
  cart = [];
  saveCart();
}

function updateCartUI() {
  const count = cartCount();
  document.querySelectorAll('.cart-badge').forEach(el => {
    el.textContent = count;
    el.classList.toggle('visible', count > 0);
  });
  renderCartItems();
}

function renderCartItems() {
  const list = document.getElementById('cartItemsList');
  const emptyEl = document.getElementById('cartEmpty');
  const footerEl = document.getElementById('cartFooter');
  if (!list) return;

  if (cart.length === 0) {
    list.innerHTML = '';
    if (emptyEl) emptyEl.style.display = 'block';
    if (footerEl) footerEl.style.display = 'none';
    return;
  }

  if (emptyEl) emptyEl.style.display = 'none';
  if (footerEl) footerEl.style.display = 'block';

  list.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img class="cart-item-img" src="${item.image}" alt="${item.name}" />
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-variant">Ukuran: ${item.size} · Warna: ${item.color}</div>
        <div class="cart-item-bottom">
          <div class="cart-item-price">${formatRp(item.price)}</div>
          <div class="cart-item-qty">
            <button class="cart-qty-btn" onclick="changeQty('${item.key}', -1)">−</button>
            <span>${item.qty}</span>
            <button class="cart-qty-btn" onclick="changeQty('${item.key}', 1)">+</button>
            <button class="cart-item-remove" onclick="removeFromCart('${item.key}')" title="Hapus">×</button>
          </div>
        </div>
      </div>
    </div>
  `).join('');

  const totalEl = document.getElementById('cartTotalPrice');
  if (totalEl) totalEl.textContent = formatRp(cartTotal());
}

// ===== TOAST =====
function showToast(msg) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// ===== CART DRAWER =====
function openCart() {
  document.getElementById('cartOverlay').classList.add('open');
  document.getElementById('cartDrawer').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cartOverlay').classList.remove('open');
  document.getElementById('cartDrawer').classList.remove('open');
  document.body.style.overflow = '';
}

// ===== MODAL PRODUCT DETAIL =====
let modalQty = 1;
let modalSelectedSize = '';
let modalSelectedColor = '';
let modalProductId = null;

function openProductModal(productId) {
  const product = products.find(p => p.id === productId);
  if (!product) return;

  modalProductId = productId;
  modalQty = 1;
  modalSelectedSize = product.sizes[0] || '';
  modalSelectedColor = product.colors[0] || '';

  const discount = discountPct(product.price, product.originalPrice);

  document.getElementById('modalImg').src = product.image;
  document.getElementById('modalImg').alt = product.name;
  document.getElementById('modalCategory').textContent = product.category.charAt(0).toUpperCase() + product.category.slice(1);
  document.getElementById('modalName').textContent = product.name;
  document.getElementById('modalPriceNow').textContent = formatRp(product.price);
  document.getElementById('modalPriceOld').textContent = product.originalPrice ? formatRp(product.originalPrice) : '';
  document.getElementById('modalDesc').textContent = product.description;
  document.getElementById('modalQtyNum').textContent = modalQty;

  // Sizes
  document.getElementById('modalSizes').innerHTML = product.sizes.map(s => `
    <button class="option-btn ${s === modalSelectedSize ? 'selected' : ''}" onclick="selectSize('${s}')">${s}</button>
  `).join('');

  // Colors
  document.getElementById('modalColors').innerHTML = product.colors.map(c => `
    <button class="option-btn ${c === modalSelectedColor ? 'selected' : ''}" onclick="selectColor('${c}')">${c}</button>
  `).join('');

  document.getElementById('modalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

function selectSize(size) {
  modalSelectedSize = size;
  document.querySelectorAll('#modalSizes .option-btn').forEach(btn => {
    btn.classList.toggle('selected', btn.textContent === size);
  });
}

function selectColor(color) {
  modalSelectedColor = color;
  document.querySelectorAll('#modalColors .option-btn').forEach(btn => {
    btn.classList.toggle('selected', btn.textContent === color);
  });
}

function changeModalQty(delta) {
  modalQty = Math.max(1, modalQty + delta);
  document.getElementById('modalQtyNum').textContent = modalQty;
}

function modalAddToCart() {
  if (!modalSelectedSize || !modalSelectedColor) {
    showToast('⚠️ Pilih ukuran dan warna terlebih dahulu!');
    return;
  }
  addToCart(modalProductId, modalSelectedSize, modalSelectedColor, modalQty);
  closeModal();
  openCart();
}

function orderViaWA(productId) {
  const product = products.find(p => p.id === (productId || modalProductId));
  if (!product) return;
  const msg = `Halo DIMERLA! Saya ingin memesan:\n\n*${product.name}*\nUkuran: ${modalSelectedSize}\nWarna: ${modalSelectedColor}\nHarga: ${formatRp(product.price)}\n\nMohon konfirmasinya, terima kasih!`;
  window.open(`https://wa.me/6281234567890?text=${encodeURIComponent(msg)}`, '_blank');
}

function cartOrderViaWA() {
  if (cart.length === 0) {
    showToast('⚠️ Keranjang masih kosong!');
    return;
  }
  let msg = 'Halo DIMERLA! Saya ingin memesan:\n\n';
  cart.forEach(item => {
    msg += `*${item.name}*\nUkuran: ${item.size} | Warna: ${item.color} | Qty: ${item.qty} | ${formatRp(item.price)}\n\n`;
  });
  msg += `*Total: ${formatRp(cartTotal())}*\n\nMohon konfirmasinya, terima kasih!`;
  window.open(`https://wa.me/6281234567890?text=${encodeURIComponent(msg)}`, '_blank');
}

// ===== RENDER PRODUCT CARD =====
function renderProductCard(product, extraClass = '') {
  const discount = discountPct(product.price, product.originalPrice);
  const badges = [];
  if (product.isNew) badges.push('<span class="badge badge-new">Baru</span>');
  if (product.isBestSeller) badges.push('<span class="badge badge-hot">Terlaris</span>');
  if (discount > 0) badges.push(`<span class="badge badge-sale">-${discount}%</span>`);

  return `
    <div class="product-card ${extraClass}" onclick="openProductModal(${product.id})">
      <div class="product-img-wrap">
        <img src="${product.image}" alt="${product.name}" loading="lazy" />
        ${badges.length ? `<div class="product-badge">${badges.join('')}</div>` : ''}
        <button class="product-quick-add" onclick="event.stopPropagation(); quickAdd(${product.id})">+ Tambah ke Keranjang</button>
      </div>
      <div class="product-info">
        <div class="product-category">${product.category}</div>
        <div class="product-name">${product.name}</div>
        <div class="product-price">
          <span class="price-now">${formatRp(product.price)}</span>
          ${product.originalPrice ? `<span class="price-old">${formatRp(product.originalPrice)}</span>` : ''}
          ${discount > 0 ? `<span class="price-discount">-${discount}%</span>` : ''}
        </div>
      </div>
    </div>
  `;
}

function quickAdd(productId) {
  const product = products.find(p => p.id === productId);
  addToCart(productId, product.sizes[0], product.colors[0], 1);
}

// ===== NAVIGATION / PAGES =====
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById('page-' + pageId);
  if (page) page.classList.add('active');

  document.querySelectorAll('.navbar-links a, .mobile-menu-links a').forEach(a => {
    a.classList.toggle('active', a.dataset.page === pageId);
  });

  window.scrollTo({ top: 0, behavior: 'smooth' });
  closeMobileMenu();

  if (pageId === 'koleksi') renderKoleksiPage();
}

// ===== BERANDA =====
function renderBeranda() {
  const bestSellers = products.filter(p => p.isBestSeller).slice(0, 4);
  const container = document.getElementById('bestSellersGrid');
  if (container) {
    container.innerHTML = bestSellers.map(p => renderProductCard(p)).join('');
  }
}

// ===== KOLEKSI PAGE =====
let currentFilter = 'semua';
let currentSearch = '';
let currentSort = 'default';

function renderKoleksiPage() {
  let filtered = [...products];

  if (currentFilter !== 'semua') {
    filtered = filtered.filter(p => p.category === currentFilter);
  }

  if (currentSearch) {
    const q = currentSearch.toLowerCase();
    filtered = filtered.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    );
  }

  if (currentSort === 'price-asc') filtered.sort((a, b) => a.price - b.price);
  else if (currentSort === 'price-desc') filtered.sort((a, b) => b.price - a.price);
  else if (currentSort === 'newest') filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
  else if (currentSort === 'bestseller') filtered.sort((a, b) => (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0));

  const container = document.getElementById('koleksiGrid');
  const noResults = document.getElementById('noResults');
  if (!container) return;

  if (filtered.length === 0) {
    container.innerHTML = '';
    if (noResults) noResults.style.display = 'block';
  } else {
    if (noResults) noResults.style.display = 'none';
    container.innerHTML = filtered.map(p => renderProductCard(p)).join('');
  }
}

function setFilter(cat) {
  currentFilter = cat;
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.filter === cat);
  });
  renderKoleksiPage();
}

// ===== MOBILE MENU =====
function openMobileMenu() {
  document.getElementById('mobileMenu').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeMobileMenu() {
  document.getElementById('mobileMenu').classList.remove('open');
  document.body.style.overflow = '';
}

// ===== CONTACT FORM =====
function submitContactForm(e) {
  e.preventDefault();
  const name = document.getElementById('contactName').value;
  const msg = document.getElementById('contactMsg').value;
  const waText = `Halo DIMERLA! Saya ${name} ingin menghubungi Anda.\n\n${msg}`;
  window.open(`https://wa.me/6281234567890?text=${encodeURIComponent(waText)}`, '_blank');
  showToast('✅ Mengarahkan ke WhatsApp...');
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', function () {
  // Init pages
  showPage('beranda');
  renderBeranda();
  updateCartUI();

  // Nav links
  document.querySelectorAll('[data-page]').forEach(el => {
    el.addEventListener('click', function (e) {
      e.preventDefault();
      showPage(this.dataset.page);
    });
  });

  // Cart buttons
  document.querySelectorAll('.cart-btn').forEach(btn => {
    btn.addEventListener('click', openCart);
  });

  // Cart overlay close
  document.getElementById('cartOverlay')?.addEventListener('click', closeCart);
  document.getElementById('cartCloseBtn')?.addEventListener('click', closeCart);

  // Modal overlay close
  document.getElementById('modalOverlay')?.addEventListener('click', function (e) {
    if (e.target === this) closeModal();
  });

  // Search
  const searchInput = document.getElementById('koleksiSearch');
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      currentSearch = this.value;
      renderKoleksiPage();
    });
  }

  // Sort
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', function () {
      currentSort = this.value;
      renderKoleksiPage();
    });
  }

  // Contact form
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', submitContactForm);
  }

  // Hamburger
  document.getElementById('hamburgerBtn')?.addEventListener('click', openMobileMenu);
  document.getElementById('mobileMenuClose')?.addEventListener('click', closeMobileMenu);
});

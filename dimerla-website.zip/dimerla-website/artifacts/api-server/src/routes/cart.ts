import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { productsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import {
  AddToCartBody,
  UpdateCartItemBody,
  GetCartResponse,
  AddToCartResponse,
  UpdateCartItemResponse,
  RemoveFromCartResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

type CartItem = {
  productId: number;
  name: string;
  price: number;
  imageUrl: string;
  quantity: number;
  size: string;
  color: string;
};

type CartStore = {
  items: CartItem[];
};

const cartStore: CartStore = { items: [] };

function computeCart(items: CartItem[]) {
  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0);
  const totalPrice = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  return { items, totalItems, totalPrice };
}

router.get("/cart", (req, res) => {
  const data = GetCartResponse.parse(computeCart(cartStore.items));
  res.json(data);
});

router.post("/cart", async (req, res) => {
  const body = AddToCartBody.parse(req.body);

  const products = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, body.productId))
    .limit(1);

  if (products.length === 0) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const product = products[0];
  const existing = cartStore.items.find(
    (i) => i.productId === body.productId && i.size === body.size && i.color === body.color
  );

  if (existing) {
    existing.quantity += body.quantity;
  } else {
    cartStore.items.push({
      productId: body.productId,
      name: product.name,
      price: parseFloat(product.price as string),
      imageUrl: product.imageUrl,
      quantity: body.quantity,
      size: body.size,
      color: body.color,
    });
  }

  const data = AddToCartResponse.parse(computeCart(cartStore.items));
  res.json(data);
});

router.put("/cart/:productId", (req, res) => {
  const productId = parseInt(req.params.productId);
  const body = UpdateCartItemBody.parse(req.body);

  const item = cartStore.items.find((i) => i.productId === productId);
  if (!item) {
    res.status(404).json({ error: "Item not in cart" });
    return;
  }

  item.quantity = body.quantity;
  if (body.size) item.size = body.size;
  if (body.color) item.color = body.color;

  if (item.quantity <= 0) {
    cartStore.items = cartStore.items.filter((i) => i.productId !== productId);
  }

  const data = UpdateCartItemResponse.parse(computeCart(cartStore.items));
  res.json(data);
});

router.delete("/cart/:productId", (req, res) => {
  const productId = parseInt(req.params.productId);
  cartStore.items = cartStore.items.filter((i) => i.productId !== productId);

  const data = RemoveFromCartResponse.parse(computeCart(cartStore.items));
  res.json(data);
});

export default router;

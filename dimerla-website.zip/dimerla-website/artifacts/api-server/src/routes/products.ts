import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { productsTable, categoriesTable } from "@workspace/db/schema";
import { eq, ilike, or } from "drizzle-orm";
import {
  GetProductsResponse,
  GetProductResponse,
  GetCategoriesResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/categories", async (_req, res) => {
  const categories = await db.select().from(categoriesTable);
  const data = GetCategoriesResponse.parse(categories);
  res.json(data);
});

router.get("/products", async (req, res) => {
  const { category, search } = req.query as { category?: string; search?: string };

  let query = db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      description: productsTable.description,
      price: productsTable.price,
      originalPrice: productsTable.originalPrice,
      imageUrl: productsTable.imageUrl,
      images: productsTable.images,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      sizes: productsTable.sizes,
      colors: productsTable.colors,
      stock: productsTable.stock,
      rating: productsTable.rating,
      reviewCount: productsTable.reviewCount,
      isFeatured: productsTable.isFeatured,
      isNew: productsTable.isNew,
    })
    .from(productsTable)
    .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id));

  const conditions = [];

  if (category) {
    conditions.push(eq(categoriesTable.slug, category));
  }

  if (search) {
    conditions.push(
      or(
        ilike(productsTable.name, `%${search}%`),
        ilike(productsTable.description, `%${search}%`)
      )!
    );
  }

  const rows = conditions.length
    ? await query.where(conditions.length === 1 ? conditions[0] : conditions.reduce((a, b) => or(a, b)!))
    : await query;

  const mapped = rows.map((r) => ({
    ...r,
    price: parseFloat(r.price as string),
    originalPrice: r.originalPrice ? parseFloat(r.originalPrice as string) : null,
    rating: parseFloat(r.rating as string),
  }));

  const data = GetProductsResponse.parse(mapped);
  res.json(data);
});

router.get("/products/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid product ID" });
    return;
  }

  const rows = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      description: productsTable.description,
      price: productsTable.price,
      originalPrice: productsTable.originalPrice,
      imageUrl: productsTable.imageUrl,
      images: productsTable.images,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      sizes: productsTable.sizes,
      colors: productsTable.colors,
      stock: productsTable.stock,
      rating: productsTable.rating,
      reviewCount: productsTable.reviewCount,
      isFeatured: productsTable.isFeatured,
      isNew: productsTable.isNew,
    })
    .from(productsTable)
    .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.id, id))
    .limit(1);

  if (rows.length === 0) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const row = rows[0];
  const mapped = {
    ...row,
    price: parseFloat(row.price as string),
    originalPrice: row.originalPrice ? parseFloat(row.originalPrice as string) : null,
    rating: parseFloat(row.rating as string),
  };

  const data = GetProductResponse.parse(mapped);
  res.json(data);
});

export default router;

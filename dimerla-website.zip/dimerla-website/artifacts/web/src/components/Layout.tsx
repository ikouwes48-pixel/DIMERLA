import { ReactNode, useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useGetCart } from "@workspace/api-client-react";
import { ShoppingBag, Menu, X, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: cart } = useGetCart();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
    setMobileMenuOpen(false);
  }, [location]);

  const navLinks = [
    { href: "/", label: "Beranda" },
    { href: "/products", label: "Koleksi" },
    { href: "/about", label: "Tentang Kami" },
    { href: "/contact", label: "Kontak" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header
        className={cn(
          "fixed top-0 w-full z-50 transition-all duration-300",
          isScrolled
            ? "bg-white/95 backdrop-blur-md shadow-md py-3 border-b border-border"
            : "bg-white/80 backdrop-blur-sm py-5 border-b border-orange-100"
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="md:hidden text-foreground hover:text-primary transition-colors"
          >
            <Menu className="w-6 h-6" />
          </button>

          {/* Logo */}
          <Link
            href="/"
            className="font-bold text-2xl md:text-3xl tracking-[0.15em] uppercase text-primary drop-shadow-sm"
          >
            DIMERLA
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "text-sm font-semibold tracking-wide uppercase transition-all duration-300 hover:text-primary relative group",
                  location === link.href ? "text-primary" : "text-foreground/70"
                )}
              >
                {link.label}
                <span
                  className={cn(
                    "absolute -bottom-1 left-0 h-0.5 bg-primary rounded-full transition-all duration-300",
                    location === link.href ? "w-full" : "w-0 group-hover:w-full"
                  )}
                />
              </Link>
            ))}
          </nav>

          {/* Keranjang */}
          <Link
            href="/cart"
            className="relative flex items-center justify-center w-10 h-10 rounded-full hover:bg-primary/10 transition-colors group"
          >
            <ShoppingBag className="w-5 h-5 text-foreground group-hover:text-primary transition-colors" />
            {cart && cart.totalItems > 0 && (
              <span className="absolute top-1 -right-1 bg-primary text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow">
                {cart.totalItems}
              </span>
            )}
          </Link>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 md:hidden"
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 h-full w-[80%] max-w-sm bg-white border-r border-orange-100 z-50 p-6 flex flex-col shadow-xl"
            >
              <div className="flex justify-between items-center mb-10">
                <span className="font-bold text-2xl tracking-widest text-primary">
                  DIMERLA
                </span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-muted-foreground hover:text-primary rounded-full hover:bg-primary/10 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <nav className="flex flex-col gap-5">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      "text-lg font-semibold tracking-wider uppercase flex items-center justify-between group py-2 border-b border-orange-50",
                      location === link.href ? "text-primary" : "text-foreground"
                    )}
                  >
                    {link.label}
                    <ChevronRight className={cn(
                      "w-4 h-4 transition-transform group-hover:translate-x-1",
                      location === link.href ? "text-primary opacity-100" : "opacity-30"
                    )} />
                  </Link>
                ))}
              </nav>

              <div className="mt-auto pt-8">
                <p className="text-xs text-muted-foreground">📍 Medan, Sumatera Utara</p>
                <p className="text-xs text-muted-foreground mt-1">📞 +62 812-3456-7890</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Konten Utama */}
      <main className="flex-1 pt-20 pb-12 flex flex-col">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-orange-50 border-t border-orange-100 pt-14 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-10">
            <div className="col-span-1 md:col-span-2">
              <h3 className="font-bold text-2xl text-primary tracking-widest uppercase mb-4">
                DIMERLA
              </h3>
              <p className="text-muted-foreground leading-relaxed max-w-sm text-sm">
                Mengangkat gaya fashion Medan. Kualitas terbaik, bahan pilihan, 
                dan desain kekinian untuk jiwa modern yang berselera tinggi.
              </p>
              <div className="flex gap-3 mt-5">
                <a href="#" className="w-9 h-9 rounded-full bg-primary/10 hover:bg-primary hover:text-white text-primary flex items-center justify-center text-xs font-bold transition-all">IG</a>
                <a href="#" className="w-9 h-9 rounded-full bg-primary/10 hover:bg-primary hover:text-white text-primary flex items-center justify-center text-xs font-bold transition-all">WA</a>
                <a href="#" className="w-9 h-9 rounded-full bg-primary/10 hover:bg-primary hover:text-white text-primary flex items-center justify-center text-xs font-bold transition-all">TK</a>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold mb-5 tracking-widest uppercase text-sm text-foreground">Jelajahi</h4>
              <ul className="space-y-3 text-muted-foreground text-sm">
                <li><Link href="/products?category=baju" className="hover:text-primary transition-colors">Baju & Pakaian</Link></li>
                <li><Link href="/products?category=sepatu" className="hover:text-primary transition-colors">Sepatu</Link></li>
                <li><Link href="/products?category=aksesoris" className="hover:text-primary transition-colors">Aksesoris</Link></li>
                <li><Link href="/products" className="hover:text-primary transition-colors">Produk Terbaru</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-5 tracking-widest uppercase text-sm text-foreground">Perusahaan</h4>
              <ul className="space-y-3 text-muted-foreground text-sm">
                <li><Link href="/about" className="hover:text-primary transition-colors">Tentang DIMERLA</Link></li>
                <li><Link href="/contact" className="hover:text-primary transition-colors">Hubungi Kami</Link></li>
                <li><a href="#" className="hover:text-primary transition-colors">Syarat & Ketentuan</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Kebijakan Privasi</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-6 border-t border-orange-100 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} DIMERLA Medan. Semua hak dilindungi.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-primary transition-colors">Instagram</a>
              <a href="#" className="hover:text-primary transition-colors">WhatsApp</a>
              <a href="#" className="hover:text-primary transition-colors">TikTok</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

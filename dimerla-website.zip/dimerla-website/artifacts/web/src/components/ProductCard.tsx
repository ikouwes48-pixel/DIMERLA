import { Link } from "wouter";
import { Product } from "@workspace/api-client-react";
import { formatIDR } from "@/lib/utils";
import { motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";

interface ProductCardProps {
  product: Product;
  index?: number;
}

export function ProductCard({ product, index = 0 }: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="group"
    >
      <Link href={`/products/${product.id}`} className="block">
        <div className="relative aspect-[3/4] bg-orange-50 rounded-2xl overflow-hidden mb-4 border border-orange-100 shadow-sm group-hover:shadow-lg group-hover:border-primary/40 transition-all duration-400">
          {product.isNew && (
            <div className="absolute top-3 left-3 z-10 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide shadow">
              Baru
            </div>
          )}
          {product.isFeatured && !product.isNew && (
            <div className="absolute top-3 left-3 z-10 bg-amber-400 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide shadow">
              Unggulan
            </div>
          )}
          
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=600&auto=format&fit=crop&q=60";
            }}
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
          
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
            <span className="bg-primary text-white px-5 py-2 rounded-full text-xs font-bold uppercase tracking-wide flex items-center gap-2 shadow-lg whitespace-nowrap">
              <ShoppingBag className="w-3.5 h-3.5" /> Lihat Detail
            </span>
          </div>
        </div>

        <div className="text-center px-2">
          <p className="text-xs text-primary/70 font-semibold uppercase tracking-widest mb-1">
            {product.categoryName}
          </p>
          <h3 className="font-bold text-base mb-2 truncate transition-colors group-hover:text-primary text-foreground">
            {product.name}
          </h3>
          <div className="flex items-center justify-center gap-3">
            <p className="text-primary font-bold text-base">
              {formatIDR(product.price)}
            </p>
            {product.originalPrice && product.originalPrice > product.price && (
              <p className="text-muted-foreground text-sm line-through">
                {formatIDR(product.originalPrice)}
              </p>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

import { Layout } from "@/components/Layout";
import { motion } from "framer-motion";

export default function About() {
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 w-full">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-primary font-bold uppercase tracking-widest text-xs mb-3">Siapa Kami</p>
          <h1 className="font-extrabold text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">
            Tentang <span className="text-primary">DIMERLA</span>
          </h1>
          <div className="w-16 h-1.5 bg-primary rounded-full mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-20 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="relative aspect-[4/5] w-full"
          >
            <div className="absolute inset-0 bg-primary/20 translate-x-5 translate-y-5 -z-10 border border-primary/40 rounded-3xl" />
            <img
              src={`${import.meta.env.BASE_URL}images/about-brand.png`}
              alt="Toko DIMERLA Medan"
              className="w-full h-full object-cover rounded-3xl shadow-xl"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <h4 className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-4">Warisan & Nilai Kami</h4>
            <h2 className="font-extrabold text-3xl md:text-4xl lg:text-5xl mb-8 leading-tight text-foreground">
              Keanggunan dari<br />
              <span className="text-primary">Tanah Batak.</span>
            </h2>

            <div className="space-y-5 text-muted-foreground leading-relaxed text-base">
              <p>
                Didirikan di kota Medan yang dinamis, DIMERLA lahir dari semangat menghadirkan fashion berkualitas tinggi yang melampaui tren sesaat. Kami percaya pada kekuatan gaya yang elegan namun tetap nyaman dipakai sehari-hari.
              </p>
              <p>
                Koleksi kami dirancang untuk jiwa modern yang menghargai bahan berkualitas, potongan yang presisi, dan desain yang segar. Dari pakaian kasual hingga formal, DIMERLA hadir sebagai pilihan fashion unggulan di Sumatera Utara.
              </p>
              <p>
                Kami hanya menggunakan bahan-bahan terbaik dan bekerja sama dengan penjahit berpengalaman, memastikan setiap produk mencerminkan standar kualitas tinggi kami. Saat kamu memakai DIMERLA, kamu memakai kepercayaan diri.
              </p>
            </div>

            <div className="mt-10 pt-8 border-t border-orange-100 grid grid-cols-3 gap-6 text-center">
              <div className="bg-primary/5 rounded-2xl p-4">
                <h4 className="font-extrabold text-3xl text-primary mb-1">2018</h4>
                <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Berdiri</p>
              </div>
              <div className="bg-primary/5 rounded-2xl p-4">
                <h4 className="font-extrabold text-3xl text-primary mb-1">15K+</h4>
                <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Pelanggan</p>
              </div>
              <div className="bg-primary/5 rounded-2xl p-4">
                <h4 className="font-extrabold text-3xl text-primary mb-1">2</h4>
                <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Toko</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Nilai-Nilai Kami */}
        <div className="bg-orange-50 rounded-3xl p-10 md:p-16">
          <h3 className="font-extrabold text-2xl md:text-3xl text-center mb-10 text-foreground">Nilai-Nilai Kami</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: "🎨",
                title: "Desain Kekinian",
                desc: "Mengikuti tren global namun tetap mempertahankan ciri khas lokal yang kuat dan unik."
              },
              {
                icon: "🌿",
                title: "Bahan Berkualitas",
                desc: "Hanya menggunakan bahan-bahan pilihan yang nyaman, tahan lama, dan ramah lingkungan."
              },
              {
                icon: "🤝",
                title: "Pelanggan Utama",
                desc: "Kepuasan pelanggan adalah prioritas kami. Setiap produk kami jual dengan layanan terbaik."
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center"
              >
                <div className="text-4xl mb-4">{item.icon}</div>
                <h4 className="font-extrabold text-lg mb-3 text-foreground">{item.title}</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}

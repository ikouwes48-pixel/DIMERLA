import { Link } from "wouter";
import {
  useGetCart,
  useUpdateCartItem,
  useRemoveFromCart,
  getGetCartQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { formatIDR } from "@/lib/utils";
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function Cart() {
  const { data: cart, isLoading } = useGetCart();
  const { mutate: updateItem } = useUpdateCartItem();
  const { mutate: removeItem } = useRemoveFromCart();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleUpdateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    updateItem(
      { productId, data: { quantity: newQuantity } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        }
      }
    );
  };

  const handleRemove = (productId: number) => {
    removeItem(
      { productId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
          toast({ title: "Produk berhasil dihapus dari keranjang" });
        }
      }
    );
  };

  const handleCheckout = () => {
    toast({
      title: "Segera Hadir!",
      description: "Fitur checkout sedang dalam pengembangan. Hubungi kami via WhatsApp untuk pemesanan.",
      variant: "default",
      className: "border-primary bg-white"
    });
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
        </div>
      </Layout>
    );
  }

  const isEmpty = !cart || cart.items.length === 0;

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">
        <div className="text-center mb-10">
          <p className="text-primary font-bold uppercase tracking-widest text-xs mb-2">Belanja Kamu</p>
          <h1 className="font-extrabold text-4xl md:text-5xl text-foreground">Keranjang Belanja</h1>
        </div>

        {isEmpty ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-32 h-32 bg-primary/10 rounded-full flex items-center justify-center mb-6">
              <ShoppingBag className="w-16 h-16 text-primary/40" />
            </div>
            <h2 className="font-extrabold text-2xl mb-3 text-foreground">Keranjangmu Kosong</h2>
            <p className="text-muted-foreground mb-6 text-center max-w-sm">
              Ayo mulai belanja dan temukan koleksi fashion terbaik dari DIMERLA!
            </p>
            <Link
              href="/products"
              className="bg-primary text-white px-8 py-3 rounded-full font-bold uppercase tracking-wide text-sm hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 transition-all"
            >
              Mulai Belanja
            </Link>
          </div>
        ) : (
          <div className="flex flex-col lg:flex-row gap-10">
            {/* Daftar Produk */}
            <div className="flex-[2]">
              <div className="hidden md:grid grid-cols-12 gap-4 pb-4 border-b border-orange-100 text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
                <div className="col-span-6">Produk</div>
                <div className="col-span-3 text-center">Jumlah</div>
                <div className="col-span-2 text-right">Total</div>
                <div className="col-span-1"></div>
              </div>

              <div className="space-y-6">
                {cart.items.map((item, idx) => (
                  <motion.div
                    key={`${item.productId}-${idx}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center bg-orange-50/50 rounded-2xl p-4 border border-orange-100 md:bg-transparent md:rounded-none md:p-0 md:border-0 md:border-b md:border-orange-100 md:pb-6"
                  >
                    {/* Info Produk */}
                    <div className="col-span-1 md:col-span-6 flex gap-4">
                      <Link href={`/products/${item.productId}`} className="shrink-0">
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-20 h-28 object-cover bg-orange-50 border border-orange-100 rounded-xl"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=200&auto=format&fit=crop&q=60";
                          }}
                        />
                      </Link>
                      <div className="flex flex-col justify-center">
                        <h3 className="font-bold text-base mb-1 hover:text-primary transition-colors text-foreground">
                          <Link href={`/products/${item.productId}`}>{item.name}</Link>
                        </h3>
                        <p className="text-primary font-bold text-sm mb-1">{formatIDR(item.price)}</p>
                        <p className="text-xs text-muted-foreground font-semibold">
                          {item.color && `Warna: ${item.color}`}
                          {item.color && item.size && ` | `}
                          {item.size && `Ukuran: ${item.size}`}
                        </p>
                      </div>
                    </div>

                    {/* Jumlah */}
                    <div className="col-span-1 md:col-span-3 flex md:justify-center">
                      <div className="flex items-center border-2 border-orange-200 rounded-xl h-10 overflow-hidden">
                        <button
                          onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                          className="w-10 h-full flex items-center justify-center hover:text-primary hover:bg-primary/5 transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-10 text-center text-sm font-extrabold text-foreground">{item.quantity}</span>
                        <button
                          onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                          className="w-10 h-full flex items-center justify-center hover:text-primary hover:bg-primary/5 transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Subtotal */}
                    <div className="col-span-1 md:col-span-2 text-left md:text-right font-extrabold text-primary">
                      {formatIDR(item.price * item.quantity)}
                    </div>

                    {/* Hapus */}
                    <div className="col-span-1 flex justify-end">
                      <button
                        onClick={() => handleRemove(item.productId)}
                        className="text-muted-foreground hover:text-red-500 transition-colors p-2 rounded-lg hover:bg-red-50"
                        title="Hapus produk"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Ringkasan Pesanan */}
            <div className="flex-1">
              <div className="bg-orange-50 border border-orange-100 p-8 rounded-3xl sticky top-28 shadow-sm">
                <h3 className="font-extrabold text-2xl mb-6 pb-4 border-b border-orange-100 text-foreground">Ringkasan Pesanan</h3>

                <div className="space-y-4 mb-6 text-sm">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal ({cart.totalItems} produk)</span>
                    <span className="font-bold text-foreground">{formatIDR(cart.totalPrice)}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Ongkos Kirim</span>
                    <span className="text-green-600 font-bold">Gratis (Medan)</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Pajak</span>
                    <span>Dihitung saat checkout</span>
                  </div>
                </div>

                <div className="border-t border-orange-100 pt-5 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="font-extrabold uppercase tracking-wide text-foreground">Total</span>
                    <span className="text-2xl text-primary font-extrabold">{formatIDR(cart.totalPrice)}</span>
                  </div>
                </div>

                <button
                  onClick={handleCheckout}
                  className="w-full h-14 bg-primary text-white font-extrabold uppercase tracking-wide rounded-xl flex items-center justify-center gap-2 hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 transition-all"
                >
                  Proses Pembayaran
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href="https://wa.me/6281234567890?text=Halo%20DIMERLA,%20saya%20ingin%20memesan..."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 w-full h-12 border-2 border-green-500 text-green-600 font-bold uppercase tracking-wide rounded-xl flex items-center justify-center gap-2 hover:bg-green-50 transition-colors text-sm"
                >
                  📞 Pesan via WhatsApp
                </a>

                <Link href="/products" className="block text-center mt-4 text-sm text-muted-foreground hover:text-primary transition-colors">
                  ← Lanjut Belanja
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}

import { Layout } from "@/components/Layout";
import { Mail, MapPin, Phone, Clock } from "lucide-react";
import { motion } from "framer-motion";

export default function Contact() {
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 w-full">
        <div className="text-center mb-14">
          <p className="text-primary font-bold uppercase tracking-widest text-xs mb-3">Hubungi Kami</p>
          <h1 className="font-extrabold text-4xl md:text-5xl mb-4 text-foreground">Kami Siap Membantu</h1>
          <div className="w-16 h-1.5 bg-primary rounded-full mx-auto mb-6"></div>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Punya pertanyaan tentang koleksi, ukuran, atau pesanan? Tim DIMERLA siap membantu kamu kapan saja!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-orange-50 p-8 md:p-10 border border-orange-100 rounded-3xl shadow-sm"
          >
            <h3 className="font-extrabold text-2xl mb-7 text-foreground">Kirim Pesan</h3>
            <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Nama Depan</label>
                  <input
                    type="text"
                    placeholder="Nama depan..."
                    className="w-full bg-white border-2 border-orange-200 rounded-xl p-3 focus:outline-none focus:border-primary transition-colors text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Nama Belakang</label>
                  <input
                    type="text"
                    placeholder="Nama belakang..."
                    className="w-full bg-white border-2 border-orange-200 rounded-xl p-3 focus:outline-none focus:border-primary transition-colors text-sm"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Email</label>
                <input
                  type="email"
                  placeholder="email@kamu.com"
                  className="w-full bg-white border-2 border-orange-200 rounded-xl p-3 focus:outline-none focus:border-primary transition-colors text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Nomor WhatsApp</label>
                <input
                  type="tel"
                  placeholder="+62 812-xxxx-xxxx"
                  className="w-full bg-white border-2 border-orange-200 rounded-xl p-3 focus:outline-none focus:border-primary transition-colors text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Pesan</label>
                <textarea
                  rows={5}
                  placeholder="Tulis pesanmu di sini..."
                  className="w-full bg-white border-2 border-orange-200 rounded-xl p-3 focus:outline-none focus:border-primary transition-colors resize-none text-sm"
                ></textarea>
              </div>
              <button className="w-full bg-primary text-white py-4 rounded-xl font-extrabold uppercase tracking-wide hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 transition-all">
                Kirim Pesan
              </button>
            </form>
          </motion.div>

          {/* Info Kontak */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col gap-8"
          >
            <div className="space-y-6">
              {[
                {
                  icon: <MapPin className="w-5 h-5" />,
                  title: "Toko Utama",
                  lines: [
                    "Jl. Jend. Sudirman No.123",
                    "Medan Polonia, Kota Medan",
                    "Sumatera Utara 20152"
                  ]
                },
                {
                  icon: <Phone className="w-5 h-5" />,
                  title: "WhatsApp",
                  lines: [
                    "+62 812-3456-7890",
                    "Klik untuk chat langsung →"
                  ],
                  href: "https://wa.me/6281234567890"
                },
                {
                  icon: <Clock className="w-5 h-5" />,
                  title: "Jam Operasional",
                  lines: [
                    "Senin - Jumat: 09.00 - 21.00 WIB",
                    "Sabtu - Minggu: 10.00 - 22.00 WIB"
                  ]
                },
                {
                  icon: <Mail className="w-5 h-5" />,
                  title: "Email",
                  lines: [
                    "halo@dimerla.com",
                    "cs@dimerla.com"
                  ]
                }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="flex gap-5 bg-orange-50 rounded-2xl p-5 border border-orange-100 hover:border-primary/30 hover:shadow-sm transition-all"
                >
                  <div className="w-12 h-12 bg-primary/10 text-primary flex items-center justify-center shrink-0 rounded-xl">
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-base mb-1 text-foreground">{item.title}</h4>
                    {item.href ? (
                      <a href={item.href} target="_blank" rel="noopener noreferrer" className="text-muted-foreground leading-relaxed text-sm hover:text-primary transition-colors">
                        {item.lines.map((line, j) => <span key={j} className="block">{line}</span>)}
                      </a>
                    ) : (
                      <div className="text-muted-foreground leading-relaxed text-sm">
                        {item.lines.map((line, j) => <span key={j} className="block">{line}</span>)}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Tombol Media Sosial */}
            <div className="bg-orange-50 rounded-2xl p-6 border border-orange-100">
              <h4 className="font-extrabold text-sm mb-4 text-foreground uppercase tracking-wider">Ikuti Kami</h4>
              <div className="flex flex-wrap gap-3">
                <a href="#" className="flex items-center gap-2 bg-pink-500 text-white px-5 py-2.5 rounded-full text-sm font-bold hover:bg-pink-600 transition-colors">
                  📸 Instagram
                </a>
                <a href="https://wa.me/6281234567890" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-green-500 text-white px-5 py-2.5 rounded-full text-sm font-bold hover:bg-green-600 transition-colors">
                  💬 WhatsApp
                </a>
                <a href="#" className="flex items-center gap-2 bg-black text-white px-5 py-2.5 rounded-full text-sm font-bold hover:bg-gray-800 transition-colors">
                  🎵 TikTok
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}

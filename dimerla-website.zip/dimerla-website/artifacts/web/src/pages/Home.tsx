import { Link } from "wouter";
import { useGetProducts, useGetCategories } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ProductCard } from "@/components/ProductCard";
import { motion } from "framer-motion";

export default function Home() {
  const { data: products, isLoading: productsLoading } = useGetProducts();
  const { data: categories } = useGetCategories();

  const featuredProducts = products?.filter(p => p.isFeatured).slice(0, 4) || [];
  const newArrivals = products?.filter(p => p.isNew).slice(0, 4) || [];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative -mt-20 min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-orange-50 via-amber-50 to-rose-50">
        <div className="absolute inset-0 z-0">
          <img
            src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
            alt="Koleksi DIMERLA"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-orange-50/60 via-transparent to-white/80" />
        </div>
        
        {/* Dekorasi lingkaran */}
        <div className="absolute top-20 right-10 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-80 h-80 bg-amber-300/20 rounded-full blur-3xl" />

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto mt-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-primary font-bold uppercase tracking-[0.3em] text-sm md:text-base mb-5 bg-primary/10 inline-block px-6 py-2 rounded-full"
          >
            🌟 Brand Fashion Terbaik dari Medan
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight text-foreground"
          >
            TAMPIL PERCAYA<br />
            <span className="text-primary">DIRI SETIAP HARI</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.35 }}
            className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto"
          >
            Koleksi baju dan sepatu premium pilihan, dari Medan untuk seluruh Indonesia.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link
              href="/products"
              className="inline-block bg-primary text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest text-sm hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 transition-all duration-300"
            >
              Lihat Koleksi
            </Link>
            <Link
              href="/about"
              className="inline-block border-2 border-primary text-primary px-10 py-4 rounded-full font-bold uppercase tracking-widest text-sm hover:bg-primary hover:text-white transition-all duration-300"
            >
              Tentang Kami
            </Link>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
          <div className="w-6 h-10 border-2 border-primary/40 rounded-full flex items-start justify-center pt-2">
            <div className="w-1.5 h-3 bg-primary/60 rounded-full" />
          </div>
        </div>
      </section>

      {/* Kategori */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-primary font-bold uppercase tracking-widest text-xs mb-2">Pilihan Kategori</p>
          <h2 className="text-3xl md:text-4xl font-extrabold mb-4 text-foreground">Temukan Gaya Kamu</h2>
          <div className="w-16 h-1.5 bg-primary rounded-full mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories?.slice(0, 3).map((category, i) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
            >
              <Link href={`/products?category=${category.slug}`} className="group block relative aspect-[4/5] overflow-hidden rounded-3xl shadow-md hover:shadow-xl transition-shadow duration-400">
                <img
                  src={category.imageUrl}
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&auto=format&fit=crop&q=60";
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex items-end justify-center pb-10">
                  <div className="text-center">
                    <h3 className="text-white font-extrabold text-2xl uppercase tracking-wide mb-2 drop-shadow">
                      {category.name}
                    </h3>
                    <span className="bg-primary text-white text-xs font-bold px-5 py-2 rounded-full uppercase tracking-wide opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      Belanja Sekarang
                    </span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Produk Unggulan */}
      <section className="py-20 bg-orange-50/60 border-y border-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <p className="text-primary font-bold uppercase tracking-widest text-xs mb-2">Pilihan Terbaik</p>
              <h2 className="text-3xl md:text-4xl font-extrabold text-foreground">Produk Unggulan</h2>
              <div className="w-12 h-1.5 bg-primary rounded-full mt-3"></div>
            </div>
            <Link href="/products" className="text-sm font-bold uppercase tracking-widest text-primary hover:text-primary/80 transition-colors border-b-2 border-primary pb-1">
              Lihat Semua →
            </Link>
          </div>

          {productsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="aspect-[3/4] bg-orange-100 rounded-2xl mb-4"></div>
                  <div className="h-4 bg-orange-100 rounded w-2/3 mx-auto mb-2"></div>
                  <div className="h-4 bg-orange-100 rounded w-1/2 mx-auto"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product, i) => (
                <ProductCard key={product.id} product={product} index={i} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Produk Terbaru */}
      {newArrivals.length > 0 && (
        <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <p className="text-primary font-bold uppercase tracking-widest text-xs mb-2">Baru Tiba</p>
              <h2 className="text-3xl md:text-4xl font-extrabold text-foreground">Koleksi Terbaru</h2>
              <div className="w-12 h-1.5 bg-primary rounded-full mt-3"></div>
            </div>
            <Link href="/products" className="text-sm font-bold uppercase tracking-widest text-primary hover:text-primary/80 transition-colors border-b-2 border-primary pb-1">
              Lihat Semua →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        </section>
      )}

      {/* Tentang Brand */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-amber-50 border-t border-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 relative w-full aspect-[4/3] md:aspect-square rounded-3xl overflow-hidden shadow-xl">
            <img
              src={`${import.meta.env.BASE_URL}images/about-brand.png`}
              alt="Toko DIMERLA Medan"
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent" />
          </div>
          <div className="flex-1">
            <p className="text-primary font-bold uppercase tracking-widest text-xs mb-3">Kisah Kami</p>
            <h2 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight text-foreground">
              Lahir di Medan,<br />
              <span className="text-primary">Mendunia.</span>
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8 max-w-xl">
              Setiap jahitan, setiap potongan, mencerminkan komitmen kami terhadap kualitas terbaik. DIMERLA lahir di kota Medan dengan semangat menghadirkan fashion yang memadukan gaya modern dan kenyamanan lokal.
            </p>
            <Link
              href="/about"
              className="inline-block bg-primary text-white px-8 py-3 rounded-full font-bold uppercase tracking-wide text-sm hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 transition-all"
            >
              Baca Cerita Kami
            </Link>
          </div>
        </div>
      </section>

      {/* Keunggulan */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {[
            { icon: "🚚", title: "Pengiriman Gratis", desc: "Gratis ongkir ke seluruh area Medan" },
            { icon: "✅", title: "Kualitas Terjamin", desc: "Bahan premium, jahitan rapi, tahan lama" },
            { icon: "🔄", title: "Garansi Tukar", desc: "Tukar produk dalam 7 hari jika ada cacat" },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="bg-orange-50 rounded-2xl p-8 border border-orange-100 hover:shadow-md hover:border-primary/30 transition-all"
            >
              <div className="text-4xl mb-4">{item.icon}</div>
              <h3 className="font-extrabold text-lg mb-2 text-foreground">{item.title}</h3>
              <p className="text-muted-foreground text-sm">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </Layout>
  );
}

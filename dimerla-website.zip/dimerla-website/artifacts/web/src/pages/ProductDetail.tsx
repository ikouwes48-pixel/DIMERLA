import { useState } from "react";
import { useRoute } from "wouter";
import { useGetProduct, useAddToCart, getGetCartQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { formatIDR, cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { ChevronRight, Star, Plus, Minus, ShoppingBag } from "lucide-react";
import { motion } from "framer-motion";

export default function ProductDetail() {
  const [, params] = useRoute("/products/:id");
  const productId = Number(params?.id);
  
  const { data: product, isLoading, error } = useGetProduct(productId, {
    query: { enabled: !!productId }
  });

  const { mutate: addToCart, isPending: adding } = useAddToCart();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [selectedSize, setSelectedSize] = useState<string>("");
  const [selectedColor, setSelectedColor] = useState<string>("");
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  const handleAddToCart = () => {
    if (!product) return;
    
    if (product.sizes.length > 0 && !selectedSize) {
      toast({ title: "Pilih ukuran terlebih dahulu", variant: "destructive" });
      return;
    }
    
    if (product.colors.length > 0 && !selectedColor) {
      toast({ title: "Pilih warna terlebih dahulu", variant: "destructive" });
      return;
    }

    addToCart(
      { data: { productId, quantity, size: selectedSize, color: selectedColor } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
          toast({
            title: "✅ Berhasil Ditambahkan!",
            description: `${quantity}x ${product.name} sudah masuk keranjang.`,
            className: "bg-white border-primary text-foreground"
          });
        }
      }
    );
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
        </div>
      </Layout>
    );
  }

  if (error || !product) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
          <h2 className="font-extrabold text-3xl mb-4 text-foreground">Produk Tidak Ditemukan</h2>
          <p className="text-muted-foreground mb-8">Produk yang kamu cari tidak ada atau sudah dihapus.</p>
        </div>
      </Layout>
    );
  }

  const images = product.images.length > 0 ? product.images : [product.imageUrl];

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-8">
          <span>Beranda</span>
          <ChevronRight className="w-3 h-3" />
          <span>{product.categoryName}</span>
          <ChevronRight className="w-3 h-3" />
          <span className="text-primary truncate max-w-[200px]">{product.name}</span>
        </div>

        <div className="flex flex-col lg:flex-row gap-12">
          {/* Galeri Foto */}
          <div className="flex-1 flex flex-col-reverse md:flex-row gap-4">
            <div className="flex md:flex-col gap-3 overflow-x-auto md:w-20 shrink-0 pb-2 md:pb-0">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(idx)}
                  className={cn(
                    "relative aspect-[3/4] w-16 md:w-full shrink-0 border-2 overflow-hidden rounded-xl transition-all",
                    activeImage === idx ? "border-primary shadow-md" : "border-transparent opacity-50 hover:opacity-100"
                  )}
                >
                  <img src={img} alt={`${product.name} ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              key={activeImage}
              className="flex-1 aspect-[3/4] bg-orange-50 border border-orange-100 rounded-3xl overflow-hidden shadow-lg"
            >
              <img
                src={images[activeImage]}
                alt={product.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=600&auto=format&fit=crop&q=60";
                }}
              />
            </motion.div>
          </div>

          {/* Informasi Produk */}
          <div className="flex-1 flex flex-col">
            <div className="mb-6">
              <p className="text-primary font-bold uppercase tracking-widest text-xs mb-2">{product.categoryName}</p>
              <h1 className="font-extrabold text-3xl md:text-4xl mb-4 text-foreground">{product.name}</h1>
              <div className="flex items-center gap-3 mb-5">
                <div className="flex items-center text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={cn("w-4 h-4", i < Math.floor(product.rating) ? "fill-amber-400" : "text-muted fill-transparent")} />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground font-semibold">{product.reviewCount} Ulasan</span>
              </div>
              <div className="flex items-end gap-4">
                <p className="text-3xl text-primary font-extrabold">{formatIDR(product.price)}</p>
                {product.originalPrice && product.originalPrice > product.price && (
                  <p className="text-lg text-muted-foreground line-through mb-1">
                    {formatIDR(product.originalPrice)}
                  </p>
                )}
                {product.originalPrice && product.originalPrice > product.price && (
                  <span className="bg-red-100 text-red-600 text-xs font-bold px-2 py-1 rounded-full mb-1">
                    Hemat {Math.round((1 - product.price / product.originalPrice) * 100)}%
                  </span>
                )}
              </div>
            </div>

            <div className="w-full h-px bg-orange-100 mb-6" />

            <div className="mb-6 text-muted-foreground leading-relaxed">
              <p>{product.description}</p>
            </div>

            {/* Warna */}
            {product.colors.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-extrabold uppercase tracking-widest mb-3 flex justify-between text-foreground">
                  <span>Pilih Warna</span>
                  <span className="text-primary font-bold">{selectedColor || "Belum dipilih"}</span>
                </h3>
                <div className="flex flex-wrap gap-3">
                  {product.colors.map(color => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={cn(
                        "px-5 py-2.5 border-2 text-sm font-bold rounded-xl transition-all",
                        selectedColor === color
                          ? "border-primary text-primary bg-primary/10 shadow"
                          : "border-orange-200 text-muted-foreground hover:border-primary/60"
                      )}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Ukuran */}
            {product.sizes.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-extrabold uppercase tracking-widest mb-3 flex justify-between text-foreground">
                  <span>Pilih Ukuran</span>
                  <span className="text-primary font-bold">{selectedSize || "Belum dipilih"}</span>
                </h3>
                <div className="flex flex-wrap gap-3">
                  {product.sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={cn(
                        "min-w-[3.5rem] h-12 px-3 border-2 flex items-center justify-center text-sm font-extrabold rounded-xl transition-all",
                        selectedSize === size
                          ? "border-primary text-primary bg-primary/10 shadow"
                          : "border-orange-200 text-muted-foreground hover:border-primary/60"
                      )}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Aksi */}
            <div className="flex gap-3 mb-8 mt-auto pt-6 border-t border-orange-100">
              <div className="flex items-center border-2 border-orange-200 rounded-xl h-14 overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-12 h-full flex items-center justify-center hover:text-primary hover:bg-primary/5 transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-10 text-center font-extrabold text-foreground">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="w-12 h-full flex items-center justify-center hover:text-primary hover:bg-primary/5 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <button
                onClick={handleAddToCart}
                disabled={adding || product.stock === 0}
                className={cn(
                  "flex-1 h-14 flex items-center justify-center gap-3 font-extrabold uppercase tracking-wide rounded-xl transition-all text-sm",
                  product.stock === 0
                    ? "bg-muted text-muted-foreground cursor-not-allowed"
                    : "bg-primary text-white hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30"
                )}
              >
                <ShoppingBag className="w-5 h-5" />
                {adding ? "Menambahkan..." : product.stock === 0 ? "Stok Habis" : "Tambah ke Keranjang"}
              </button>
            </div>

            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex justify-between border-b border-orange-100 pb-3">
                <span className="font-semibold">Ketersediaan</span>
                <span className={product.stock > 0 ? "text-green-600 font-bold" : "text-red-500 font-bold"}>
                  {product.stock > 0 ? `Tersedia (${product.stock} stok)` : "Stok Habis"}
                </span>
              </div>
              <div className="flex justify-between border-b border-orange-100 pb-3">
                <span className="font-semibold">Pengiriman</span>
                <span className="text-primary font-bold">Gratis ke area Medan</span>
              </div>
              <div className="flex justify-between pb-3">
                <span className="font-semibold">Garansi</span>
                <span>Tukar dalam 7 hari</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import { useGetProducts, useGetCategories } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ProductCard } from "@/components/ProductCard";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Products() {
  const [searchParams] = useLocation();
  const urlParams = new URLSearchParams(window.location.search);
  
  const [category, setCategory] = useState<string>(urlParams.get("category") || "");
  const [search, setSearch] = useState<string>(urlParams.get("search") || "");
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  const { data: products, isLoading } = useGetProducts({
    category: category || undefined,
    search: search || undefined
  });
  
  const { data: categories } = useGetCategories();

  const clearFilters = () => {
    setCategory("");
    setSearch("");
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-1 w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <p className="text-primary font-bold uppercase tracking-widest text-xs mb-2">Semua Produk</p>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-3 text-foreground">Koleksi DIMERLA</h1>
          <p className="text-muted-foreground text-sm">
            {category
              ? categories?.find(c => c.slug === category)?.name || category
              : "Semua Produk"}{" "}
            {products ? `(${products.length} produk)` : ""}
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-10">
          {/* Mobile Filter Toggle */}
          <div className="lg:hidden flex items-center justify-between border-b border-orange-100 pb-4">
            <button
              onClick={() => setShowMobileFilters(true)}
              className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-foreground"
            >
              <SlidersHorizontal className="w-4 h-4 text-primary" /> Filter
            </button>
            {(category || search) && (
              <button onClick={clearFilters} className="text-xs text-primary font-bold underline">
                Hapus Filter
              </button>
            )}
          </div>

          {/* Sidebar / Filter */}
          <aside className={cn(
            "lg:w-60 shrink-0 transition-all duration-300",
            showMobileFilters ? "fixed inset-0 z-50 bg-white p-6 overflow-y-auto shadow-2xl" : "hidden lg:block"
          )}>
            {showMobileFilters && (
              <div className="flex justify-between items-center mb-8 lg:hidden">
                <span className="font-extrabold text-xl text-foreground">Filter</span>
                <button onClick={() => setShowMobileFilters(false)}>
                  <X className="w-6 h-6 text-foreground" />
                </button>
              </div>
            )}

            <div className="space-y-8">
              {/* Pencarian */}
              <div>
                <h3 className="text-sm font-extrabold uppercase tracking-widest mb-3 text-foreground">Cari Produk</h3>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Nama produk..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full bg-orange-50 border border-orange-200 rounded-xl pb-2 pt-2 pl-9 pr-3 focus:outline-none focus:border-primary transition-colors text-sm"
                  />
                  <Search className="w-4 h-4 text-primary absolute left-3 top-2.5" />
                </div>
              </div>

              {/* Kategori */}
              <div>
                <h3 className="text-sm font-extrabold uppercase tracking-widest mb-3 text-foreground">Kategori</h3>
                <ul className="space-y-2">
                  <li>
                    <button
                      onClick={() => { setCategory(""); setShowMobileFilters(false); }}
                      className={cn(
                        "text-sm font-semibold px-4 py-2 rounded-xl w-full text-left transition-colors",
                        category === ""
                          ? "bg-primary text-white"
                          : "text-muted-foreground hover:bg-primary/10 hover:text-primary"
                      )}
                    >
                      Semua Produk
                    </button>
                  </li>
                  {categories?.map((cat) => (
                    <li key={cat.id}>
                      <button
                        onClick={() => { setCategory(cat.slug); setShowMobileFilters(false); }}
                        className={cn(
                          "text-sm font-semibold px-4 py-2 rounded-xl w-full text-left transition-colors",
                          category === cat.slug
                            ? "bg-primary text-white"
                            : "text-muted-foreground hover:bg-primary/10 hover:text-primary"
                        )}
                      >
                        {cat.name}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              {(category || search) && (
                <button
                  onClick={clearFilters}
                  className="w-full border-2 border-primary text-primary py-3 rounded-xl text-xs font-extrabold uppercase tracking-widest hover:bg-primary hover:text-white transition-colors"
                >
                  Hapus Semua Filter
                </button>
              )}
            </div>
          </aside>

          {/* Grid Produk */}
          <div className="flex-1">
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-[3/4] bg-orange-100 rounded-2xl mb-4"></div>
                    <div className="h-4 bg-orange-100 rounded w-2/3 mx-auto mb-2"></div>
                    <div className="h-4 bg-orange-100 rounded w-1/2 mx-auto"></div>
                  </div>
                ))}
              </div>
            ) : products?.length === 0 ? (
              <div className="text-center py-24 border-2 border-dashed border-orange-200 rounded-3xl bg-orange-50/50">
                <Search className="w-12 h-12 text-primary/30 mx-auto mb-4" />
                <h3 className="font-extrabold text-2xl mb-2 text-foreground">Produk Tidak Ditemukan</h3>
                <p className="text-muted-foreground">Coba ubah kata kunci atau filter yang dipilih.</p>
                <button
                  onClick={clearFilters}
                  className="mt-6 bg-primary text-white px-6 py-2 rounded-full font-bold uppercase tracking-wide text-sm hover:bg-primary/90 transition-colors"
                >
                  Hapus Filter
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products?.map((product, i) => (
                  <ProductCard key={product.id} product={product} index={i} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

import { Link } from "wouter";
import { Layout } from "@/components/Layout";

export default function NotFound() {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[70vh] px-4 text-center">
        <div className="text-9xl font-extrabold text-primary/15 mb-4 select-none">404</div>
        <h2 className="font-extrabold text-3xl md:text-4xl mb-4 text-foreground">Halaman Tidak Ditemukan</h2>
        <p className="text-muted-foreground max-w-md mx-auto mb-8 text-lg">
          Maaf, halaman yang kamu cari tidak ada atau sudah dipindahkan.
        </p>
        <Link
          href="/"
          className="bg-primary text-white px-8 py-4 rounded-full font-extrabold uppercase tracking-widest text-sm hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 transition-all"
        >
          Kembali ke Beranda
        </Link>
      </div>
    </Layout>
  );
}

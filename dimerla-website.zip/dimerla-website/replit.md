# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Contains the DIMERLA online fashion store — a full-stack e-commerce website for a clothing and shoe brand based in Medan, Indonesia.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Frontend**: React + Vite, TailwindCSS, TanStack React Query, wouter
- **Build**: esbuild (CJS bundle)

## Features

- Homepage with hero banner, featured products, category grid
- Products listing with filter by category and search
- Product detail page with image gallery, size/color selector, add to cart
- Shopping cart with quantity management
- About page with DIMERLA brand story
- Contact page with Medan address and WhatsApp

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── web/                # React + Vite frontend (DIMERLA store)
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Database Schema

- `categories` — product categories (Baju, Sepatu, Aksesoris)
- `products` — product listings with prices, sizes, colors, images

## API Endpoints

- `GET /api/products` — list products (supports `?category=slug&search=term`)
- `GET /api/products/:id` — product detail
- `GET /api/categories` — list categories
- `GET /api/cart` — get current cart (in-memory session)
- `POST /api/cart` — add item to cart
- `PUT /api/cart/:productId` — update cart item
- `DELETE /api/cart/:productId` — remove from cart

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all packages as project references.

- **Always typecheck from the root** — run `pnpm run typecheck`
- **`emitDeclarationOnly`** — only emit `.d.ts` files during typecheck
- **Project references** — when package A depends on package B, A's `tsconfig.json` must list B in its `references` array

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly` using project references
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API client and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes
